# Resume Generator

A fast way to create, generate and download your resume

Resumes create, managed and downlaoded in PDF file format. Made width PHP, JavaScript, HTML, CSS and MySQL Database and runs on my [PHP Waker Framework](https://github.com/ankain-lesly/php-framework-waker) stack.
