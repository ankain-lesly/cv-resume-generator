export const token_id = "_sess";
export const APP_ROOT = "http://localhost:8080:";
export const STORAGE_KEY = "enter_resume_data_key_here";
