<!-- RENAME FILE TO -->
<!-- config.php -->
<?php
// Custom Assets
define("ROOT_URL", "https://www.website.com");
define("MAIN_EMAIL", "email@server.com");

// Host Server


// Local Database
define("DB_HOST", "host");
define("DB_USERNAME", "user");
define("DB_PASSWORD", "password");
define("DB_NAME", "databasename");
