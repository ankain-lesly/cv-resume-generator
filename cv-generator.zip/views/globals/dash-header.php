<header class="header-h flex between main-header">
  <div class="left-caption flex">
    <button class="btn-sitebar padd"><i class="fas fa-bars"></i></button>
    <h3>Dashboard</h3>
  </div>
  <nav class="flex">
    <button class="padd"><i class="fas fa-bell"></i></button>
    <button class="padd theme-btn"><i class="fas fa-sun"></i></button>
    <div class="flex ml-x">
      <?php include_once "profile-nav.php" ?>
    </div>
  </nav>
</header>