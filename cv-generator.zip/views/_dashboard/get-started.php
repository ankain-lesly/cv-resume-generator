<style>
.get_started li {
  list-style-type: disc;
  list-style: disc;
  display: list-item;
}

.get_started ul {
  margin: 2rem;
}
</style>
<main class="section-p" style="background-color: var(--color-bg); color: #fff">
  <div class="container-x p-2">
    <!-- Page View Start -->
    <div class="get_started">
      <h2>We will provide helpful links to resources that will guide you on how to use</h2>

      <ul>
        <li>The Editor</li>
        <li>FIle Upload Features</li>
        <li>And more...</li>
      </ul>

      <a href="/app/" class="btn btn-s">Back to Dashboard</a>
    </div>
  </div>
  <!-- Page View Ends -->
</main>