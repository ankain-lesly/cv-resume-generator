<main>
  <!-- Page View Start -->
  <div class="dashboard">
    <div class="mini-head">
      <h3>Settings</h3>
    </div>
    <br>
  </div>

</main>