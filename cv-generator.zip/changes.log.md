# UPDATES AND CHANGES

## Tracking key changes

1. Changed Header On Mobile
   Removed header login logout

## Add CTA Button on hero section

-> Onclick take to design window
-> After loader has stopped
-> Load Templates Window for users to select
-> On show with a query URI from the section cta button action
-> On select Load Template and update states
